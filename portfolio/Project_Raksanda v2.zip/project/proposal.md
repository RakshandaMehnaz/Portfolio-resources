---
id: litvis

narrative-schemas:
  - ../../lectures/narrative-schemas/proposal.yml
---

@import "../../lectures/css/datavis.less"

# Project Proposal

{(whoami|} {|whoami)}

{(task|}

You should complete this datavis project proposal by **Sunday 5th March, 5pm UK time** ensuring you have committed and pushed it to GitHub. Successful submissions by that time will be awarded up to **5 marks** towards your coursework assessment total.

{|task)}

{(questions|}

- Add your question here
- Add your question here
- etc.

{|questions)}

{(datasources|}

_A brief sentence or two with links to data sources._

{|datasources)}

{(justification|}

_A couple of sentences on why you need datavis to answer your research questions._

{|justification)}
